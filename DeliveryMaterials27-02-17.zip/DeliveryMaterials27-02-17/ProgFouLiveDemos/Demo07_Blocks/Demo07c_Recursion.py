''' Recursive functions call themselves '''

def to_ten(i):
    print i  
    i += 1 # += is the same as i = i+ 1, as is i++ in many languages
    if i < 10: to_ten(i)  
    
to_ten(0)

''' A loop would be another way to do this, but recursion is often more elegant '''
'''

i = 0
while i < 10:
    print i
    i += 1
    
'''