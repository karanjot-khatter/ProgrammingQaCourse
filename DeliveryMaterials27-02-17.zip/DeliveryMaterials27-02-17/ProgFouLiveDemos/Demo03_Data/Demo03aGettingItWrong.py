# The import is needed to use the maxsize/maxint properties
import sys

x = sys.maxsize #could be maxint if python 2.x is being used

print x
print type(x)

x = x + 1

print x
print type(x)

# Gotcha - Floating Point Calculations
x = 0.1
y = 0.2

print x + y
