package Demo05;

public class Vehicle {

	public int passengers;
	public int engineSize;
	public String colour;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle vehicle1 = new Vehicle(5, 1998, "Black");
		Vehicle vehicle2 = new Vehicle(2, 750, "Green");
		Vehicle vehicle3 = new Vehicle(52, 3498, "Red");
		
		System.out.println(vehicle1);
		System.out.println(vehicle2);
		System.out.println(vehicle3);
		
		System.out.println(vehicle1.colour);
		System.out.println(vehicle2.engineSize);
		System.out.println(vehicle3.passengers);
	}
	
	public Vehicle(int passengers, int engineSize, String colour) {
		this.passengers = passengers;
		this.engineSize = engineSize;
		this.colour = colour;
	}

	@Override
	public String toString() {
		return "Vehicle [passengers=" + passengers + ", engineSize=" + engineSize + ", colour=" + colour + "]";
	}
	
	

}
