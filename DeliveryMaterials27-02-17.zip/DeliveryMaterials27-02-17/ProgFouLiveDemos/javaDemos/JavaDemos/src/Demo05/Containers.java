package Demo05;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import java.util.TreeMap;

public class Containers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("**************** QUEUES *****************");
		Queue<String> queue = new LinkedList<String>();
		
		queue.add("b");
		queue.add("s");
		queue.add("a");
		queue.add("t");
		
		System.out.println(queue);
		
		queue.offer("b");
		queue.offer("s");
		queue.offer("a");
		queue.offer("t");
		
		System.out.println(queue);
		
		queue.poll(); // Remove in order added
		queue.poll();
		queue.poll();

		System.out.println(queue);
		
		queue.remove();
		
		System.out.println(queue); // Remove in order added
		
		System.out.println("**************** STACKS *****************");
		Stack<String> stack = new Stack<>();

		stack.push("b");
		stack.push("s");
		stack.push("a");
		stack.push("t");
		
		System.out.println(stack);
		
		stack.pop();
		stack.pop();
		stack.pop();
	
		System.out.println(stack);

		System.out.println("**************** MAPS *****************");
		
		Map<String, Integer> map = new HashMap<>();
		
		map.put("x", 5);
		map.put("f", 2);
		map.put("e", 1);
		map.put("s", 4);
		map.put("w", 19);
		
		System.out.println(map);
		
		System.out.println(map.get("s"));
		
		System.out.println("**************** TREEMAPS *****************");
		
		// TreeMaps
		// Provide efficient means of storing key/value pairs in sorted order
		// Allows rapid retrieval
		TreeMap<String, Double> tm = new TreeMap<String, Double>();
		
		tm.put("Hugh", new Double(3434.34));
		tm.put("Pugh", new Double(123.45));
		tm.put("Barney McGrew", new Double(7654.232));
		tm.put("Cuthbert", new Double(8787.123));
		tm.put("Dibble", new Double(456.654));
		tm.put("Grub", new Double(2562.64));
		
		System.out.println(tm);
		System.out.println(tm.get("Cuthbert"));
	}

}
