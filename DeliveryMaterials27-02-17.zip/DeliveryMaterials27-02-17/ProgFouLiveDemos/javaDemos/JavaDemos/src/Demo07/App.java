package Demo07;

public class App {

	public static void main(String[] args) {

		Vehicle vehicle1 = new Vehicle(5, 1998, "Black");
		Vehicle vehicle2 = new Vehicle(2, 750, "Green");
		Vehicle vehicle3 = new Vehicle(52, 3498, "Red");
		
		System.out.println(vehicle1);
		System.out.println(vehicle2);
		System.out.println(vehicle3);
		
		// Trying to change properties directly
//		vehicle1.colour = "Blue";
//		vehicle2.engineSize = 1000;
//		vehicle3.passengers = 45;
		
		// Class 'setter methods' have to be used
		vehicle1.setColour("Blue");
		vehicle2.setEngineSize(1000);
		vehicle3.setPassengers(45);
		
		// Trying to print out properties directly
//		System.out.println(vehicle1.colour);
//		System.out.println(vehicle2.engineSize);
//		System.out.println(vehicle3.passengers);
		
		// Class 'getter methods' have to be used
		System.out.println(vehicle1.getColour());
		System.out.println(vehicle2.getEngineSize());
		System.out.println(vehicle3.getPassengers());
		
		// Printing out whole Vehicle is OK because of public toString method...
		System.out.println(vehicle1);
		System.out.println(vehicle2);
		System.out.println(vehicle3);
		
	}

}
