package Demo07;

public class Vehicle {
	private int passengers;
	private int engineSize;
	private String colour;
	
	public Vehicle(int passengers, int engineSize, String colour) {
		this.passengers = passengers;
		this.engineSize = engineSize;
		this.colour = colour;
	}

	public int getPassengers() {
		return passengers;
	}

	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}

	public int getEngineSize() {
		return engineSize;
	}

	public void setEngineSize(int engineSize) {
		this.engineSize = engineSize;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	@Override
	public String toString() {
		return "Vehicle [passengers=" + passengers + ", engineSize=" + engineSize + ", colour=" + colour + "]";
	}

	
}
