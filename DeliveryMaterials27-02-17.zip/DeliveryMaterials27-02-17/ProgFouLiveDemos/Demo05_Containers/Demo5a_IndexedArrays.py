# Declaring an array
myArray = [43, 67, 22, 33, 90, 99]
print myArray

# Accessing a particular element of an array
print myArray[0]

# Setting element values
myArray[2] = myArray[5]
myArray[4] = 120
print myArray

# Adding to the end of an array
# AKA push
myArray.append(6)
print myArray

# Inserting in an array
# Not possible in all languages!
myArray.insert(0, 100)
print myArray

# Removing from the end of an Array
# AKA pop
myArray.pop()
print myArray


#Removing any element from an array
# Can also use remove and del in Python
myArray.pop(2)
#myArray.remove(2)
#del myArray[2]
print myArray

#Sorting an array in ascending order
myArray.sort()            # Permanently sorts the array
#print (sorted(myArray))   # Does a temporary sort
print myArray

# Sorting an array in descending order
myArray.sort(reverse=True)
print myArray