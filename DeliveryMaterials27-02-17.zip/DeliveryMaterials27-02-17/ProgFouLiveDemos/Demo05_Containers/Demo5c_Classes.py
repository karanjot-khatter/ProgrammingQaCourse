class Account:
    numCreated = 0                                  # Public class variable
    def __init__(self, name, initial):              # Constructor
        self.__balance = initial                    # Notional private variable
        self.__name = name                          # Notional private variable
        Account.numCreated += 1

    def deposit(self, amt):                         # Public class method
        self.__balance = self.__balanace + amt

    def withdraw(self, amt):                        # Public class method
        self.__balance = self.__balance - amt

    def getBalance(self):                           # Public class method
        return self.__balance

    def getName(self):
        return self.__name

account1 = Account("Current Account", 100)          # Create instance of Account
account2 = Account("Savings Account", 500)          # Create instance of Account

print "Balance of " + account1.getName() + " is : £" + str(account1.getBalance())

account1.withdraw(20)                               # Take out of Current Account
print account1.getBalance()                         # Display new balance

account2.deposit(100)                               # Pay into Savings Account
print account2.getBalance()                         # Display new balance

account1.__balance = 1000000                        # Note: private is notional

print account1.__balance                            # Balance has been changed

print "Number of accounts created: " + (str(Account.numCreated))
print account1.numCreated
print account2.numCreated

account3 = Account("Secret Account", 50000)         # Create instance of Account
print "New account created..."

print "Number of accounts created: " + (str(Account.numCreated))
print account1.numCreated
print account2.numCreated
print account3.numCreated
