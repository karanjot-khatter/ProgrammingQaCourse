#This is a single line comment
''' This 
is
a
multi-line
comment '''

print "Hello, World!";
