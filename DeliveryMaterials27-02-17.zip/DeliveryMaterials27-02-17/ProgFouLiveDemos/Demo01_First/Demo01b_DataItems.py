x = 1
y = x
x = "Hello, World!"

print x
print "The value of y is: " + str(y)

name = "Joe Bloggs"
print name

name = "Josephine Bloggs"
print name

# importing and using the easygui to make a simple graphical application
import easygui

easygui.msgbox("Hello, World!")
