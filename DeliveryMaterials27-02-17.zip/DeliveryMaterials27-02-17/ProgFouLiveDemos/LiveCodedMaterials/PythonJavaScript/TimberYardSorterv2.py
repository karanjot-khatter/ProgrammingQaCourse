'''
Created on 28 Feb 2017
Timber Yard Sorter v2
@author: Administrator
'''

print "Welcome to the Log Sorter and Plank calculator!"

''' Allow user to enter no of logs in delivery '''
noDelivered = raw_input("How many logs in the delivery? ")

noDelivered = int(noDelivered)  # Convert into an integer

logLengths = []                 # Define empty array for log lengths

deliveryCounter = 0             # Define a loop counter

''' While loop only executes while the condition is true '''
while deliveryCounter < noDelivered:
    logLength = raw_input("Please enter log length (in m): ")
    logLength = int(logLength)
    logLengths.append(logLength)
    deliveryCounter += 1
    
print "Confirmation of log lengths entered: " + str(logLengths)






