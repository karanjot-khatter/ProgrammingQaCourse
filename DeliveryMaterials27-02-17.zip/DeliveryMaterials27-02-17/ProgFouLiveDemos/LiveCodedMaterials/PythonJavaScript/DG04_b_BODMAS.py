'''
Created on 27 Feb 2017

@author: Administrator
'''

''' BODMAS, governs order of expression evaluation
    1. Brackets 
    2. Other operations or functions
    3. Division
    4. Multiplication
    5. Addition
    6. Subtraction
'''
total = 2 + 3 * 10 / 5 # What does total equal?
print total

total2 = 1 + 4 - 5 * 10 / 5 # What does total2 equal?
print total2

total3 = (2+3)*10/5 # What does this equal?
print total3






