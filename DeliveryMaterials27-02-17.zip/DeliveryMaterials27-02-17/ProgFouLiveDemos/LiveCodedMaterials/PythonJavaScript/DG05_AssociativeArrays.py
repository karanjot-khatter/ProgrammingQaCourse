'''
Created on 28 Feb 2017

@author: Administrator
'''
''' Associative arrays are sometimes called Maps
They can also be the same as objects in some languages
Whereas indexed arrays have a number for each element,
associative arrays are indexed by the 'key'.
This means data can have a more semantic meaning,
although the example below does not demonstrate this!'''

someMap = {"c" : 4, "a" : 3, "q" : 8, "w" : 2}

print someMap
print someMap["q"]
print someMap["w"]

someMap["w"] = 99
print someMap["w"]

someMap["x"] = 77
print someMap

# So why use over an indexed array

student1 = ["John", "Smith", "QAPROGFOU", 1234, 5]
print student1

student2 = {"firstName" : "John", "lastName" : "Smith", "course" : "QAPROGFOU", "stNo" : 1234, "duration" : 5}
print student2
print student2["stNo"]

student3 = {"firstName" : "Joe", "lastName" : "Bloggs", "course" : "QAJAVSC", "stNo" : 4234, "duration" : 3}
print student3["stNo"]

classRoom = [student2, student3]
print classRoom
print classRoom[0]
print classRoom[1]

print classRoom[0]["duration"]
