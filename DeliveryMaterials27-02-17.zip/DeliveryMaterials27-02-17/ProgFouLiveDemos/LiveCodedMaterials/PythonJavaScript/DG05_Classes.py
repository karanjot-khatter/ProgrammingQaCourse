'''
Created on 28 Feb 2017

@author: Administrator
'''

class Account:
    numCreated = 0              # Public class Variable
    
    def __init__(self, name, initial_balance):       # CONSTUCTOR - Special Method
        self.__balance = initial_balance            # Notional private variable
        self.__name = name
        Account.numCreated += 1
        # Account.numCreated++
        
    def deposit(self, amt):                     # Public class method
        self.__balance += amt
        
    def withdraw(self, amt):                    # Public class method
        self.__balance -= amt
        
    def getBalance(self):
        return self.__balance
    
    def getName(self):
        return self.__name

 
#  Use the Account class

account1 = Account("Current Account", 100)
account2 = Account("Savings Account", 500)

#print account1
#print account2

print "Balance of " + account1.getName() + " is : �" + str(account1.getBalance())

account1.withdraw(20)
print account1.getBalance()

account2.deposit(200)
print account2.getBalance()

# Notional private variable
account1.__balance = 1000000
print account1.__balance

print "Number of accounts created: " + (str(Account.numCreated))

print account1.numCreated
print account2.numCreated

account3 = Account("Secret Stash", 50000)
print "New account created..."

print "Number of accounts created: " + (str(Account.numCreated))
print account1.numCreated
print account2.numCreated
print account3.numCreated













        
