'''
Created on 28 Feb 2017

@author: Administrator
'''
# Declaring an array
myArray = [43, 67, 22, 33, 90, 99]
print myArray

# Accessing a particular element
print myArray[2]

# Setting or changing element values
myArray[4] = 120
print myArray
myArray[2] = myArray[5]
print myArray

# Adding to the end of an array
# AKA PUSH
print myArray.append(6)
print myArray

# Inserting into the array
# Not possible in all languages...
myArray.insert(4, 100)
print myArray

# Remove from the end of an array
# AKA POP
print myArray.pop()
print myArray

# Removing any element from an array
print myArray.pop(4)
print myArray
# In python we can also use myArray.remove(4) OR del myArray[4]

# Sort an array in ascending order
#myArray.sort()      # Permanently sort the array
print (sorted(myArray))     # Temporary sort of the array
print myArray

# Sorting an array in descending order
myArray.sort(reverse=True)
print myArray







