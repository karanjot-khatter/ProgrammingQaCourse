'''
Created on 1 Mar 2017

@author: Administrator
'''

''' Function to perform a particular action '''

def addTenAndFive():
    a = 10
    b = 5
    print a + b
    
# addTenAndFive()

''' Function to perform an action with some supplied data '''

def addTwoSuppliedNumbers(num1, num2):
    print num1 + num2
    
# addTwoSuppliedNumbers(18, 2)
# addTwoSuppliedNumbers(100, 124123.234)
# addTwoSuppliedNumbers(10, 5)

''' Function to return a value of a particular action '''
# def  returnAnswerOfTwoAddedNumbers(num1, num2):
#     return num1 + num2
# 
# print returnAnswerOfTwoAddedNumbers(7, 12)

''' Use function as the argument to another '''
# addTwoSuppliedNumbers(10, returnAnswerOfTwoAddedNumbers(10, 20))

''' Passing variables by copy '''

x = 42

def myFunc(num2):
    num1 = 27
    x = 105
    #pass by reference would mean that num2 is also 105
    print num1
    print num2
    print x
    print num1 * num2
    
myFunc(x)




