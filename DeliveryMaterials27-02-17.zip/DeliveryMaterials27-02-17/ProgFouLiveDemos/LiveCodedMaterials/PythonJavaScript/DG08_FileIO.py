'''
Created on 1 Mar 2017

@author: Administrator
'''
''' Writing to a file '''
path = "c:\\Users\\Public\\Desktop\\text.txt"

newFile = open(path, "w")
 
newFile.write("hello world\n")
newFile.write("hello world\n")
newFile.write("hello world\n")
newFile.write("hello world\n")
newFile.write("hello world\n")

''' Reading from a file '''

newFile = open(path, "r")
# text = newFile.read()
# print text

''' Read line by line '''
lines = newFile.readlines()
for line in lines:
    print line