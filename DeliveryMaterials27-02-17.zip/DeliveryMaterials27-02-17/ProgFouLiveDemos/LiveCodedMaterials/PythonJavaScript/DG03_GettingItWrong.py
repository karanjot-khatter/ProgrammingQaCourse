'''
Created on 27 Feb 2017

@author: Administrator
'''

import sys

x = sys.maxint

print x
print type(x)

x = x + 1

print x
print type(x)
