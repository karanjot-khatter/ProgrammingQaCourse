'''
Created on 27/02/2017

@author: administrator
'''

print "Hello, World!"

# This is a single line comment

name = "Joe Bloggs"
print name

name = "Josephine Bloggs"
print name

import easygui

easygui.msgbox("Hello World!")

x = 0.1
y = 0.2

print x + y

