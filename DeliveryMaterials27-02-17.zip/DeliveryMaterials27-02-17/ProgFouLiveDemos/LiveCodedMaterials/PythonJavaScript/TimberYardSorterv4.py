'''
Created on 28 Feb 2017
Timber Yard Sorter v4
@author: Administrator
'''
import math

print "Welcome to the Log Sorter and Plank calculator!"

''' Allow user to enter no of logs in delivery '''
noDelivered = raw_input("How many logs in the delivery? ")

noDelivered = int(noDelivered)  # Convert into an integer

logLengths = []                 # Define empty array for log lengths

deliveryCounter = 0             # Define a loop counter

''' While loop only executes while the condition is true '''
while deliveryCounter < noDelivered:
    logLength = raw_input("Please enter log length (in m): ")
    logLength = int(logLength)
    logLengths.append(logLength)
    deliveryCounter += 1
    
print "Confirmation of log lengths entered: " + str(logLengths)

''' v3 Add log sorting '''
smallLogs = []
mediumLogs = []
longLogs = []
extraLongLogs = []
errorLengths = []

for logLength in logLengths:
    
    if (logLength > 0) & (logLength <= 5):
        smallLogs.append(logLength)
    elif (logLength > 5) & (logLength <=10):
        mediumLogs.append(logLength)
    elif (logLength > 10) & (logLength <=20):
        longLogs.append(logLength)
    elif (logLength > 20):
        extraLongLogs.append(logLength)
    else:
        errorLengths.append(logLength)
        
print "SMALL Log lengths (0-5m): " + str(smallLogs)
print "MEDIUM Log lengths (6-10m): " + str(mediumLogs)
print "LONG Log lengths (11-20m): " + str(longLogs)
print "EXTRA LONG Log lengths (21m +): " + str(extraLongLogs)
print "ERRORS : " + str(errorLengths)

''' v4 - Calculate how many 2m logs can be made '''

smallLog2mLengths = 0;
mediumLog2mLengths = 0;
longLog2mLengths = 0;
extraLongLog2mLengths = 0;

for logLength in smallLogs:
    smallLog2mLengths += int(math.floor(logLength / 2))

for logLength in mediumLogs:
    mediumLog2mLengths += int(math.floor(logLength / 2))
    
for logLength in longLogs:
    longLog2mLengths += int(math.floor(logLength / 2))
    
for logLength in extraLongLogs:
    extraLongLog2mLengths += int(math.floor(logLength / 2))
    
total = smallLog2mLengths + mediumLog2mLengths + longLog2mLengths + extraLongLog2mLengths

print "2m planks from SMALL pile: " + str(smallLog2mLengths)
print "2m planks from MEDIUM pile: " + str(mediumLog2mLengths)
print "2m planks from LONG pile: " + str(longLog2mLengths)
print "2m planks from EXTRA LONG pile: " + str(extraLongLog2mLengths)
print "Total number of 2m planks from delivery: " + str(total)


# logPile = [smallLogs, mediumLogs, longLogs, extraLongLogs]
# 
# 
# for pile in logPile:
#     for logs in pile:
        







