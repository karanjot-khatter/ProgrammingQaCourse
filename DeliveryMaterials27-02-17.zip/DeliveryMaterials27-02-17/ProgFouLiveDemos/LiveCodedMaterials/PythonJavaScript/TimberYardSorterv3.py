'''
Created on 28 Feb 2017
Timber Yard Sorter v3
@author: Administrator
'''

print "Welcome to the Log Sorter and Plank calculator!"

''' Allow user to enter no of logs in delivery '''
noDelivered = raw_input("How many logs in the delivery? ")

noDelivered = int(noDelivered)  # Convert into an integer

logLengths = []                 # Define empty array for log lengths

deliveryCounter = 0             # Define a loop counter

''' While loop only executes while the condition is true '''
while deliveryCounter < noDelivered:
    logLength = raw_input("Please enter log length (in m): ")
    logLength = int(logLength)
    logLengths.append(logLength)
    deliveryCounter += 1
    
print "Confirmation of log lengths entered: " + str(logLengths)

''' v3 Add log sorting '''
smallLogs = []
mediumLogs = []
longLogs = []
extraLongLogs = []
errorLengths = []

for logLength in logLengths:
    
    if (logLength > 0) & (logLength <= 5):
        smallLogs.append(logLength)
    elif (logLength > 5) & (logLength <=10):
        mediumLogs.append(logLength)
    elif (logLength > 10) & (logLength <=20):
        longLogs.append(logLength)
    elif (logLength > 20):
        extraLongLogs.append(logLength)
    else:
        errorLengths.append(logLength)
        
print "SMALL Log lengths (0-5m): " + str(smallLogs)
print "MEDIUM Log lengths (6-10m): " + str(mediumLogs)
print "LONG Log lengths (11-20m): " + str(longLogs)
print "EXTRA LONG Log lengths (21m +): " + str(extraLongLogs)
print "ERRORS : " + str(errorLengths)






