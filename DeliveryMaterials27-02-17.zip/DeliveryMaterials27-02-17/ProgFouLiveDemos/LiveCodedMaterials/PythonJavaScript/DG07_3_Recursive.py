'''
Created on 1 Mar 2017

@author: Administrator
'''

''' Recursive functions call themselves '''

def to_ten(i):
    print i
    i += 1
    if i < 11 : to_ten(i)
    
to_ten(0)

''' A loop could have done this too, recursion is often more elegant '''

i = 0
while i < 11:
    print i
    i += 1
