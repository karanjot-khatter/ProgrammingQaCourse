'''
Created on 28 Feb 2017
Timber Yard Sorter V1
@author: Administrator
'''

print "Welcome to the Log Sorter and Plank calculator!"

''' Allow the user to enter the length of a log '''
''' Use python's raw_input function '''

firstLog = raw_input("Please enter the 1st log length in m: ")
print "1st log length entered is " + str(firstLog) + "m"

''' Repeat for a second log... '''
secondLog = raw_input("Please enter the 2nd log length in m: ")
print "2nd log length entered is " + str(secondLog) + "m"

''' Repeat for a third log... '''
thirdLog = raw_input("Please enter the 3rd log length in m: ")
print "3rd log length entered is " + str(thirdLog) + "m"

''' Store values in an array '''
logs = [firstLog, secondLog, thirdLog]
print "List of log lengths entered: " + str(logs)