import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.TreeMap;

public class Containers {

	public static void main(String[] args) {
		
		System.out.println("*************** QUEUES ****************");
		
		Queue<String> queue = new LinkedList<>();
		
		queue.add("b");
		queue.add("s");
		queue.add("a");
		queue.add("t");
		
		System.out.println(queue);
		
		queue.offer("b");
		queue.offer("s");
		queue.offer("a");
		queue.offer("t");
		
		System.out.println(queue);
		
		queue.poll();
		queue.poll();
		queue.poll();
		
		System.out.println(queue);
		
		queue.remove();
		System.out.println(queue);
		
		System.out.println("*************** STACKS ****************");

		Stack<String> stack = new Stack<>();
		
		stack.push("b");
		stack.push("s");
		stack.push("a");
		stack.push("t");
		
		System.out.println(stack);
		
		stack.pop();
		stack.pop();
		stack.pop();
		
		System.out.println(stack);
		
		System.out.println("**************** TREEMAPS *****************");
		
		// TreeMaps
		// Provide efficient means of storing key/value pairs in sorted order
		// Allows rapid retrieval
		TreeMap<String, Double> tm = new TreeMap<String, Double>();
		
		tm.put("Hugh", new Double(3434.34));
		tm.put("Pugh", new Double(123.45));
		tm.put("Barney McGrew", new Double(7654.232));
		tm.put("Cuthbert", new Double(8787.123));
		tm.put("Dibble", new Double(456.654));
		tm.put("Grub", new Double(2562.64));
		
		System.out.println(tm);
		System.out.println(tm.get("Cuthbert"));
	}

}
