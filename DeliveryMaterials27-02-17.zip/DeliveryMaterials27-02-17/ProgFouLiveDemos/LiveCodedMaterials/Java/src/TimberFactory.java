import java.util.ArrayList;
import java.util.Scanner;

public class TimberFactory {

	public static void main(String[] args) {

		ArrayList<Integer> logs = new ArrayList<>();
		ArrayList<Integer> smallLogs = new ArrayList<>();
		ArrayList<Integer> mediumLogs = new ArrayList<>();
		ArrayList<Integer> largeLogs = new ArrayList<>();
		ArrayList<Integer> massiveLogs = new ArrayList<>();
		
		Integer smallPile[], mediumPile[], largePile[], massivePile[];
		
 		int logCount, logLength;
		int counter, total;
		int sm2mL, m2mL, l2mL, xl2mL;
		Scanner logInput;

		System.out.println("Hello and welcome to the timber factory system!!!");

		// The below asks user for a command line input and stores the result in a
		// variable by using the Scanner class and nextInt function
		// It then confirms the log lengths entered

		System.out.println("How many logs would you like to process?");
		logInput = new Scanner(System.in);
		logCount = logInput.nextInt();

		counter = 0;
		while(counter < logCount) {
			System.out.println("Please enter the log length:");
			logInput = new Scanner(System.in);
			logLength = logInput.nextInt();
			System.out.println(logLength + " was inputted");
			logs.add(logLength);
			counter++;
		}

		logInput.close();

		System.out.println("Confirmation of log lengths entered: " + logs);

		// This section of code will sort the logs in the log list into small and large
		// logs - large logs will be more than 10m

		for(int lengthOfLog : logs) {
			if(lengthOfLog < 6) {
				smallLogs.add(lengthOfLog);
			}
			else if(lengthOfLog < 11) {
				mediumLogs.add(lengthOfLog);
			}
			else if(lengthOfLog < 20) {
				largeLogs.add(lengthOfLog);
			} else {
				massiveLogs.add(lengthOfLog);
			}
		}

		System.out.println("After sorting the logs there are:");
		System.out.println("There are " + smallLogs.size() + " small logs;");
		System.out.println("There are " + mediumLogs.size() + " medium logs;");
		System.out.println("There are " + largeLogs.size() + " large logs;");
		System.out.println("There are " + massiveLogs.size() + " massive logs;");

		// Calculate how many 2m planks can be made from each pile and in total
		sm2mL = 0;
		m2mL = 0;
		l2mL = 0;
		xl2mL = 0;

		for(int i = 0, j = smallLogs.size(); i < j; i++) {
			sm2mL += Math.floor(smallLogs.get(i) / 2);
		}

		for(int i = 0, j = mediumLogs.size(); i < j; i++) {
			m2mL += Math.floor(mediumLogs.get(i) / 2);
		}

		for(int i = 0, j = largeLogs.size(); i < j; i++) {
			l2mL += Math.floor(largeLogs.get(i) / 2);
		}

		for(int i = 0, j = massiveLogs.size(); i < j; i++) {
			xl2mL += Math.floor(massiveLogs.get(i) / 2);
		}

		total = sm2mL + m2mL + l2mL + xl2mL;

		System.out.println("After making 2m planks:");
		System.out.println("There are " + sm2mL + " 2m planks from small logs;");
		System.out.println("There are " + m2mL + " 2m planks from medium logs;");
		System.out.println("There are " + l2mL + " 2m planks from large logs;");
		System.out.println("There are " + xl2mL + " 2m planks from massive logs;");
		System.out.println("There are " + total + " 2m planks in total;");
		
		// To just create a total, we could have made an array that contained the sorted arrays
		// First we need to convert the ArrayLists to an Integer array (for Java)
//		smallPile = new Integer[smallLogs.size()];
//		mediumPile = new Integer[mediumLogs.size()];
//		largePile = new Integer[largeLogs.size()];
//		massivePile = new Integer[massiveLogs.size()];
//		
//		smallPile = smallLogs.toArray(smallPile);
//		
//		System.out.println(smallPile);
		
		

	}
}