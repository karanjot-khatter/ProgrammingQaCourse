public class Account {

  public static int numCreated = 0;
  private String name;
  private int balance;

  public Account (String name, int initial) {
    this.name = name;
    this.balance = initial;
    numCreated++;
  }

  public void deposit(int amt) {
    this.balance += amt;
  }

  public void withdraw(int amt) {
    this.balance -= amt;
  }

  public int getBalance() {
    return this.balance;
  }

  public String getName() {
    return this.name;
  }

  public static void main(String[] args) {
    Account account1 = new Account("Current Account", 100);
    Account account2 = new Account("Savings Account", 500);

    System.out.println("Balance of " + account1.getName() + " is : �" + account1.getBalance());
    System.out.println("Balance of " + account2.getName() + " is : �" + account2.getBalance());
    
    account1.withdraw(20);
    System.out.println(account1.getBalance());
    
    account2.deposit(200);
    System.out.println(account2.getBalance());
    
    account1.balance = 100000;                   // Note: This will not work outside of this class as balance is private
    System.out.println(account1.getBalance());
  }
}