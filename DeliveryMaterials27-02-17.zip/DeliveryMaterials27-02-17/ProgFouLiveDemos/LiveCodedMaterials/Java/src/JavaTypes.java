
public class JavaTypes {

	public static void main(String[] args) {
		
		//String name = "Ed";
		//System.out.println(name);
		
		int x = Integer.MAX_VALUE;
		
		System.out.println(x);
		
		x = x + 10;
		
		System.out.println(x);
		
		String c = "2";
		int a = 2;
		String b = "two";
		
		System.out.println(a + c);
		//System.out.println(a * c);
		System.out.println(a + b);
		
		double d = 0.1;
		double e = 0.2;
		System.out.println(d + e);
		
		String f;
		f = null;
		System.out.println(f);

	}

}
