''' Declaring variables '''

x = 10
y = 20
z = 30

# Adding values together

addition = x + y + z
print addition

# Subtraction
subtraction = z - y
print subtraction

# Multiplication
multiplication = x * y
print multiplication

# Division
division = z / x
print division

# Modulo
modulo1 = z % x 
modulo2 = z % y

print "The remainder of 30/10 is: " + str(modulo1)
print "The remainder of 30/20 is: " + str(modulo2)
