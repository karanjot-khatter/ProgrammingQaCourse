'''
Created on 3 Oct 2016

@author: edwright
'''

''' BODMAS, governs order of expression evaluation
    1. Brackets 
    2. Other operations or functions
    3. Division
    4. Multiplication
    5. Addition
    6. Subtraction
'''

total = 2+3*10/5 # What does this evaluate to, hint 8
print total

total = 1+4-5*10/5 # What does this evaluate to, hint -5
print total

total = (2+3)*10/5 # What does this evaluate to, hint 10
print total