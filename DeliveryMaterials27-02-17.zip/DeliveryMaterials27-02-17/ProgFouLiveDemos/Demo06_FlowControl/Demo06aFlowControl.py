'''
Timber processing factory simulation:

The aim of this project is for you to develop a simple application,
which demonstrates the fundamental aspects of programming.

Timber factory simulation requirements:

    1. User can enter a number of logs,
        each log is entered with its length in m.
    2. Logs must be sorted into different length groups, small, large etc. to help plan logistics
    3. The factory aims to create as many 2meter length planks as possible, from the logs collected


'''

print "Hello and welcome to the timber factory system!!!"

''' The below asks user for a command line input and stores the result in a variable
    by using the raw_input function
'''
# first = raw_input("Please enter 1st Log Length: ")
# print  "1st Timber length entered:"
# print first
#
# ''' We repeat this for a second entry '''
# second = raw_input("Please enter 2nd Log Length: ")
# print "2nd Timber length entered:"
# print second
#
# ''' We repeat this for a third entry '''
# third = raw_input("Please enter 3rd Log Length: ")
# print "3rd Timber length entered:"
# print third
#
# ''' We can store these values in a list in order
# to group them together for easier processing '''
#
# logs = [first,second,third]
# print "list of logs:"
# print logs
#
# logs.sort()
# print "list of logs: " +str(logs)
#
# ''' Rather than repeating lines of code we can use loops,
# So for example the timber entry system can be rewritten using a loop as follows '''
#
# # the most basic for loop in python
# # for each value in the logs list provide, it will repeat the lines of code within it
# print "print logs using for loop 1"
# for l in logs:
#     print "log of length "+str(l)+"m"
#
# # the other for loop in python
# print "print logs using for loop 2"
# size = len(logs)
# # Creates range from 0 to upto size of the logs list,
# # e.g. 0,1,2,3...
# # python lists are zero-based meaning that in order to access the first element in the list,
# # we must use 0, rather than 1
# rnge = range(0, size)
# for i in rnge:
#     print "log#"+str(i)+" log of length "+str(logs[i])+"m"

# While loops in python - more efficient and user controlled way to enter log lengths!

noOfLogs = raw_input("How many logs would you like to process? :")

noOfLogs = int(noOfLogs)
enteredLogs = []
count = 0
while count<noOfLogs:
    log  = raw_input("Please enter a Log Length in meters: ")
    log = int(log)
    print "log length entered: ", log
    enteredLogs.append(log)
    count = count + 1

print "Confirmation of all logs lengths entered: " + str(enteredLogs)

#===============================================================================
# smallLogs = []
# largeLogs = []
#
# for l in enteredLogs:
#     # boolean conditions
#     #logLengthGreaterThan0 = l>0
#     #logLengthLessThanOrEqualTo5 = l<=5
#     # if else statement
#     #if logLengthGreaterThan0 & logLengthLessThanOrEqualTo5:
#     if l > 0 & l < 5:
#         smallLogs.append(l)
#     else:
#         largeLogs.append(l)
#
# print "confirmation of SMALL (0-5m) logs entered: " + str(smallLogs)
# print "confirmation of LARGE (>5m) logs entered: " + str(largeLogs)
#===============================================================================

# We decide we need two more groups LARGER and LARGEST
# We create lists for these and empty the existing lists
smallLogs = []
largeLogs = []
largerLogs = []
largestLogs = []
for l in enteredLogs:

    # We need to add some more conditions
    # Messy way but good for demonstrating variable naming and also boolean evaluations
#     logLengthGreaterThan0 = l>0
#     logLengthLessThanOrEqualTo5 = l<=5
#     logLengthGreaterThan5 = l>5
#     logLengthLessThanOrEqualTo10 = l<=10
#     logLengthGreaterThan10 = l>10
#     logLengthLessThanOrEqualTo20 = l<=20
#
#     if logLengthGreaterThan0 & logLengthLessThanOrEqualTo5:
#         smallLogs.append(l)
#     elif logLengthGreaterThan5 & logLengthLessThanOrEqualTo10:
#         largeLogs.append(l)
#     elif logLengthGreaterThan10 & logLengthLessThanOrEqualTo20:
#         largerLogs.append(l)
#     else:
#         largestLogs.append(l)

    if (l > 0) & (l <= 5):
        smallLogs.append(l)
    elif (l > 5) & (l <= 10):
        largeLogs.append(l)
    elif (l > 10) & (l <= 20):
        largerLogs.append(l)
    else:
        largestLogs.append(l)


print "Confirmation of no. of SMALL (0-5m) logs entered: ", smallLogs
print "Confirmation of no. of LARGE (5-10m) logs entered: ", largeLogs
print "Confirmation of no. of LARGER (10-20m) logs entered: ", largerLogs
print "Confirmation of no. of LARGEST (greater than 20m) logs entered: ", largestLogs

# Try running the program again with the following log sizes:
# 1,1,3,3,5,5,10,10,11,11
# What do you expect to see in each group?

# Calculate how many 2m planks can be made:

noOf2mPlanksFromSmall = 0

import math

for l in smallLogs:
    noOf2mPlanksFromSmall += int(math.floor(l / 2))

print "Number of 2m planks made from SMALL logs is: " + str(noOf2mPlanksFromSmall)

noOf2mPlanksFromLarge = 0

for l in largeLogs:
    noOf2mPlanksFromLarge += int(math.floor(l/2))

print "Number of 2m planks made from LARGE logs is: " + str(noOf2mPlanksFromLarge)

noOf2mPlanksFromLarger = 0

for l in largerLogs:
    noOf2mPlanksFromLarger += int(math.floor(l/2))

print "Number of 2m planks made from LARGER logs is: " + str(noOf2mPlanksFromLarger)

noOf2mPlanksFromLargest = 0

for l in largerLogs:
    noOf2mPlanksFromLargest += int(math.floor(l/2))

print "Number of 2m planks made from LARGEST logs is: " + str(noOf2mPlanksFromLargest)

total = noOf2mPlanksFromSmall + noOf2mPlanksFromLarge + noOf2mPlanksFromLarger + noOf2mPlanksFromLargest

print "Number of 2m planks made from DELIVERY of logs is: " + str(total)
