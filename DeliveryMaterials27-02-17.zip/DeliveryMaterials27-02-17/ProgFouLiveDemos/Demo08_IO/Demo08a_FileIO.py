pathdir
"C:\\Users\\Public\\Desktop\\text.txt"
file = open(path, "w")
file.write("hello")
#file.write("hello")
#file.write("hello")
#file.write("hello")
#file.write("hello")

file = open(path, "r")
text = file.read()
print text

#lines = file.readlines()
#for l in lines:
#    print l
