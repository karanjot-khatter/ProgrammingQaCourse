# For QAPROGFOU Exercises
# python setup.py build
# python setup.py install
# python setup.py bdist_wininst
from distutils.core import setup

setup (name = 'containers',
       version = '1.0',
       description = 'Simple containers',
       py_modules = ['containers']
       )