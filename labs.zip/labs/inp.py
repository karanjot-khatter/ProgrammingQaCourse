import sys

for line in sys.stdin.read():
    print line
    
print 'Goodbye'