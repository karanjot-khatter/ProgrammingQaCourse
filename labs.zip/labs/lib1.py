var = 42

