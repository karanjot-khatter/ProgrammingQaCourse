# Chapter 02 First Steps

# This race requires 45 laps, how much fuel is required?
FuelPerLap = 2.25   
Laps = 45
FuelRequirement = Laps * FuelPerLap     
print "Fuel requirement is", FuelRequirement, "kg"