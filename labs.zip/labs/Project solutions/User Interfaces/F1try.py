# Chapter 02 First Steps

# This race requires 45 laps, how much fuel is required?
FuelPerLap = 2.25   
Laps = 45
FuelRequirement = Laps * FuelPerLap     
print "Fuel requirement is", FuelRequirement, "kg"
print

# Chapter 04 Variables and Operators
# a) Typically a car will carry an extra 50% for contingency 
Fuel = FuelRequirement * 1.5
print "Full fuel load:",Fuel,"kg"

# b) The qualifying lap time was 80.45 seconds
#    However, that was with only 5kg of fuel
#    Each 10 kg of fuel decreases the lap time by 0.35 seconds
#    What will be the lap time for the first lap with all the required fuel on board?

QLapTime = 80.45

# Reduction in lap time for 5kg is:
QReduction5 = (0.35/10) * 5

# Theoretical initial lap time would be
TLapTime = QLapTime - QReduction5
print "Theoretical lap time:", TLapTime, "seconds"

LapOneTime = TLapTime + ((Fuel/10) * 0.35)
print "Lap one time:", LapOneTime, "seconds"

# If time allows
# What will be the lap time after 20 laps?
Fuel20 = Fuel - (FuelPerLap * 20)
Lap20Time = TLapTime + ((Fuel20/10) * 0.35)   
print "Lap 20 time:", Lap20Time, "seconds"

# Tyre wear also increases lap time by 0.05 seconds per lap
# Assuming new tyres at the start of the race, what is the lap time after lap 20 now?
Lap20Time = Lap20Time + (0.05 * 20)
print "Lap 20 time (tyres):", Lap20Time, "seconds"
print

LapTimes = []
Lap = 1
FuelSoFar = Fuel
while Lap <= Laps:
    FuelSoFar = FuelSoFar - FuelPerLap
    LapTime = TLapTime + ((FuelSoFar/10) * 0.35)
    LapTime = LapTime + (0.05 * Lap)    # Tyre wear
    #print "Lap",Lap,"time:", LapTime, "seconds"
    LapTimes.append(LapTime)
    Lap = Lap + 1

print LapTimes

# Chapter 10 User Interfaces
# Graph
import matplotlib.pyplot as plot

x_axis = xrange(1,Laps+1)

"""
LapTimes = []
for Lap in (x_axis):
    FuelSoFar = Fuel - (FuelPerLap * Lap)
    LapTime = TLapTime + ((FuelSoFar/10) * 0.35)
    LapTime = LapTime + (0.05 * Lap)    # Tyre wear
    #print "Lap",Lap,"time:", LapTime, "seconds"
    LapTimes.append(LapTime)
"""

"""
LapTimes2 = []
TyreLap = 0
for Lap in (x_axis):
    FuelSoFar = Fuel - (FuelPerLap * Lap)
    if Lap == 20:
        TyreLap = 0
    
    TyreLap = TyreLap + 1
    LapTime = TLapTime + ((FuelSoFar/10) * 0.35)
    LapTime = LapTime + (0.05 * TyreLap)    # Tyre wear 
    
    #print "Lap",Lap,"time:", LapTime, "seconds"
    LapTimes2.append(LapTime)

plot.plot(x_axis, LapTimes,'k-', LapTimes2,'r-')
"""
plot.ylabel('Lap time (seconds)')
plot.xlabel('Lap number')

plot.plot(x_axis, LapTimes)
plot.show()








