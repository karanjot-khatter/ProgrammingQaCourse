# Chapter 02 First Steps

# This race requires 45 laps, how much fuel is required?
FuelPerLap = 2.25   
Laps = 45
FuelRequirement = Laps * FuelPerLap     
print "Fuel requirement is", FuelRequirement, "kg"
print

# Chapter 04 Variables and Operators
# a) Typically a car will carry an extra 50% for contingency 
Fuel = FuelRequirement * 1.5
print "Full fuel load:",Fuel,"kg"

# b) The qualifying lap time was 80.45 seconds
#    However, that was with only 5kg of fuel
#    Each 10 kg of fuel decreases the lap time by 0.35 seconds
#    What will be the lap time for the first lap with all the required fuel on board?

QLapTime = 80.45

# Reduction in lap time for 5kg is:
QReduction5 = (0.35/10) * 5

# Theoretical initial lap time would be
TLapTime = QLapTime - QReduction5
print "Theoretical lap time:", TLapTime, "seconds"

# Chapter 06 part 2

Lap = 1
TyreLap = 1
FuelSoFar = Fuel
while Lap <= Laps:
    FuelSoFar = FuelSoFar - FuelPerLap
    LapTime = TLapTime + ((FuelSoFar/10) * 0.35)
    
    if Lap == 20:
        print "New tyres"
        TyreLap = 1
    else:
        LapTime = LapTime + (0.05 * TyreLap)  

    print "Lap",Lap,"time:", LapTime, "seconds"
    Lap = Lap + 1
    TyreLap = TyreLap + 1



