/* Simple C program illustrating application builing */

#include <stdio.h>
#include "MySub.h"

int main (int argc, char *argv[])
{
    int answer = MySub(27, 28);

    printf("%d\n", answer);

    return 0;
}
