"""
Run a job
"""

class Job:

    __JobNumber = 0
    
    def __init__(self, message = None):
        Job.__JobNumber += 1
       
        if message is None:
            self.__msg = "Job %d" % (Job.__JobNumber)
        else:
            self.__msg = message

    def runit(self):
        print self.__msg


from containers import *

ast = Stack()

for i in xrange(5):
    ast.push(Job())

print "jobs stored"

ast.pop().runit()
        
