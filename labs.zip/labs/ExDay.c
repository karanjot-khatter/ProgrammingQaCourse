/* ExDay.c
   Chapter 07 Program Structure
   C Example
*/
#include <stdio.h>
#include <string.h>

char * ExpandDay(const char *day, char *FullDay)
{
    /* C is not a dynamic language, so if the computed
       day string is too long it could crash the program! */

    if (strlen(day) > 6) {
		fprintf (stderr, "The day %s is too long!\n", day);
		return NULL;
    }

    /* Copy day -> FullDay */
    strcpy (FullDay, day);

    /* Change the first character to upper case */
    FullDay[0] = toupper(FullDay[0]);

    /* Add "day" onto the end */
    strcat (FullDay, "day");

    return FullDay;
}

int main (int argc, char *argv[])
{
    char FullDay[10] = {0};

	printf ("%s\n", ExpandDay("sun", FullDay));
	printf ("%s\n", ExpandDay("wednes", FullDay));
	printf ("%s\n", ExpandDay("fri", FullDay));

	return 0;
}
