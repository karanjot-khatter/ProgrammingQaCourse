/* MySub.h - Used in the Application Building exercise */
/* This is a C prototype, it declares the function signature */

int MySub (int num1, int num2);
