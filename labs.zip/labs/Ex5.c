/* Simple C program illustrating scope */

#include <stdio.h>

int main (int argc, char *argv[])
{
    int x = 42;

    {
        int x = 37;
        int y = 12;

        printf("%d\n", x);
    }

    printf("%d\n", x);

    return 0;
}
