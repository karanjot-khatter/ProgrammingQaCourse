var = 37

import lib1
import lib2

print lib1.var
print lib2.var

print var