
import showcard
import random

# This line is commented out
showcard.set_timeout(0.2)

cards = list(range(1,52))
random.shuffle(cards)

try:
    for card in cards:
        filename = 'BMP' + str(card) + '.gif'
        showcard.display_file(filename)
        
except KeyboardInterrupt:
    exit('Bye...')