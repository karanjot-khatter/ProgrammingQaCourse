#!/usr/bin/python

def myfunc():
    return 42
    
x = myfunc

print x

y = x + 1

print y