/* MySub - Used in the Application Building exercise */

int MySub (int num1, int num2)
{
    return num1 * num2;
}
