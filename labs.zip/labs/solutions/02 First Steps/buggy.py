#!/usr/bin/python

import datetime
date = datetime.date.today()
#date = date.today()

#print 'Today's date is', date
print "Today's date is", date

days = raw_input("Please enter a number of days:")

#difference = datetime.timedelta(days = days)
difference = datetime.timedelta(days = int(days))

print "In", days, "days the date will be:", date + difference
#print("In", days, "days the date will be:", date + difference

print "Goodbye!"