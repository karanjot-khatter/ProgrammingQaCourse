
def ExpandDay(day):
    
    if day[-1] == '\n':
        day = day[:-1]
    FullDay = day[0].upper() + day[1:] + 'day'
    return FullDay

fhin  = open("days.txt", "r")
fhout = open("OutDays.txt", "w")

for day in fhin:
    print >> fhout,ExpandDay(day[:-1])