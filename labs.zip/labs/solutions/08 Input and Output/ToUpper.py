FileR = open("locale.txt","r")
FileW = open("out.txt","w")

for line in FileR:
    line = line.upper()
    FileW.write(line)

FileR.close()
FileW.close()
