"""
    pin3a.py
"""

MasterPIN = "1234"
SuppliedPIN = None
attempts = 0

while SuppliedPIN != MasterPIN and attempts < 3:

    attempts = attempts + 1
    SuppliedPIN = raw_input("Please enter your PIN:")

    if SuppliedPIN == MasterPIN:
        print "Correct PIN after",attempts, \
              "tries, well done!"
    else:
        print "Incorrect PIN after", attempts, \
              "attempts"
    

