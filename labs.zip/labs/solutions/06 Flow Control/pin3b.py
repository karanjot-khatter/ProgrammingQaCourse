"""
    pin3b.py
"""

MasterPIN = "1234"
SuppliedPIN = None
attempts = 0

while SuppliedPIN != MasterPIN:

    attempts = attempts + 1
    SuppliedPIN = raw_input("Please enter your PIN:")

    if SuppliedPIN == MasterPIN:
        print "Correct PIN after",attempts,"tries, well done!"
    else:
        print "Incorrect PIN after", attempts, "attempts"

    if attempts >= 3: 
        break
