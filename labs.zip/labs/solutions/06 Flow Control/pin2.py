"""
    pin2.py
"""

MasterPIN = "1234"
SuppliedPIN = None

while SuppliedPIN != MasterPIN:
    SuppliedPIN = raw_input("Please enter your PIN:")

    if SuppliedPIN == MasterPIN:
        print "Correct PIN, well done!"
    else:
        print "Incorrect PIN"
    

