"""
    pin4.py
"""
import getpass

MasterPIN = "1234"
SuppliedPIN = None
attempts = 0

while SuppliedPIN != MasterPIN and attempts < 3:

    attempts = attempts + 1
    SuppliedPIN = getpass.getpass(
                  "Please enter your PIN:")

    if SuppliedPIN == MasterPIN:
        print "Correct PIN after",attempts, \
              "tries, well done!"
    else:
        print "Incorrect PIN after", attempts, \
              "attempts"
    

