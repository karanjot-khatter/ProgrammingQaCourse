# Perl
use warnings;
use strict;

print "$$\n";
