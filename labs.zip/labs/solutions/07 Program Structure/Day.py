
def ExpandDay(day):
    
    FullDay = day.capitalize() + 'day'
    return FullDay
    
print ExpandDay('sun')
print ExpandDay('wednes')
print ExpandDay('fri')