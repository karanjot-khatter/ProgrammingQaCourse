from containers import *

print "\nStack:"
astack = Stack()
astack.push(42)
astack.push(37)
astack.push(99)
astack.push(12)
astack.push(101)
print astack

print astack.pop()
print astack.pop()
print astack

astack.push("another")
print astack

print astack.pop()
print astack.pop()
print astack.pop()
print astack.pop()

"""
This is an example of exception handling.
You are not expected to have done that!
We put it here so that our program continues 
after the error
"""
try:
    print astack.pop()
except IndexError:
    import traceback
    traceback.print_exc()


print "\nQueue:"

aq = Queue()
aq.enqueue(42)
aq.enqueue(37)
aq.enqueue(99)
aq.enqueue(12)
aq.enqueue(101)

print len(aq), "items in the queue"
print aq
aq.dequeue()
print aq

print "\nDeque"

dq = Deque()

dq.push(42)
dq.unshift(37)
dq.unshift(99)
dq.push(12)
dq.unshift(101)
print dq

# Here's another possibility:

while len(dq) > 0:
    print dq.pop()

