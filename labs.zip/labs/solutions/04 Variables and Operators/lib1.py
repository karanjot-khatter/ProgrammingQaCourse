var = 42

from lib2 import var