print "Hello, Ed!"

name = "Joe Bloggs"
print name
