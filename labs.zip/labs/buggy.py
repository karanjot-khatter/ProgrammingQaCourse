#!/usr/bin/python

import datetime

date = date.today()

print 'Today's date is', date

days = raw_input("Please enter a number of days:")

difference = datetime.timedelta(days = days)

print("In", days, "days the date will be:", date + difference

print "Goodbye!"