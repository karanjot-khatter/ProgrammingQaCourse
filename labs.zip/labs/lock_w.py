"""
   lock_w.py

   Run two copies, each in its own terminal session.
   Allow one to write a number of records, then switch
   to the other showing that it blocks on the same record.
   Switch back and release the lock, and show that the
   blocked process proceeds.

   Also run with lock_r to demonstrate interaction with
   read locks.

   Default filename is rlock.dat

   Clive Darke QA
"""

import msvcrt
import os
import sys
import time
from datetime import datetime

REC_LIM   = 20

if len(sys.argv) < 2:
    pFilename = "rlock.dat"
else:
    pFilename = sys.argv[1]

fh = open(pFilename, "w")

# Do only once
Record = dict()
Record['Pid'] = os.getpid()

for i in range(REC_LIM):
    Record['Text'] = "Record number %02d" % i
    Record['Time'] = datetime.now().strftime("%H:%M:%S")

    # Get the size of the area to be locked
    line = str(Record) + "\n"
    
    # Get the current start position
    start_pos  = fh.tell()          
    
    print "Getting lock for",Record['Text']
    msvcrt.locking(fh.fileno(), msvcrt.LK_RLCK, len(line)+1)
    fh.write(line)       # This advances the current position
    
    raw_input("Written record %02d, clear the lock?" % i)
    
    # Save the end position
    end_pos = fh.tell()
    
    # Reset the current position before releasing the lock
    fh.seek(start_pos)
    msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, len(line)+1)
    
    # Go back to the end of the written record
    fh.seek(end_pos)
    
    print      

fh.close()